# Life Signal v0.1.3

Patch focus:

- fixes route typing weak points from v0.1.2;
- fixes the `item possibly undefined` TypeScript issue in `app/item/[id].tsx`;
- wraps the app in `SignalProvider`;
- replaces direct mock imports in screens with local state via `useSignals()`;
- adds real mock actions: Save, Snooze, Resolve;
- keeps Context AI Chat local/mock-only.

## Install into existing Expo project

Copy these folders over your current project root:

```txt
app/
src/
```

Then clear Expo typed-route cache:

```bash
npx expo start -c
```

On Windows PowerShell, if old typed routes still remain:

```powershell
Remove-Item -Recurse -Force .expo
npx expo start -c
```

## Expected routes

```txt
/
/inbox
/radar
/actions
/vault
/item/[id]
```

Important: `(tabs)` is a route group and is not part of the URL.

import { useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import {
  buildMockAssistantReply,
  ChatMessage,
  createInitialAssistantMessage,
  createUserMessage,
  quickPrompts,
} from '../../src/lib/itemChat';
import { priorityColor, priorityLabel } from '../../src/lib/priority';
import { actionLabel } from '../../src/lib/signalSelectors';
import { useSignals } from '../../src/state/SignalStore';
import { colors } from '../../src/theme/colors';

export default function ItemDetailScreen() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const itemId = Array.isArray(id) ? id[0] : id;
  const { getItemById, resolveItem, saveItem, snoozeItem } = useSignals();
  const item = itemId ? getItemById(itemId) : undefined;
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  useEffect(() => {
    if (!item) {
      setMessages([]);
      return;
    }

    setMessages([createInitialAssistantMessage(item)]);
  }, [item?.id]);

  if (!item) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.title}>Signal not found</Text>
        <Text style={styles.body}>The selected item does not exist in mock data.</Text>
      </View>
    );
  }

  const selectedItem = item;

  function submitPrompt(prompt: string) {
    const text = prompt.trim();

    if (!text) {
      return;
    }

    const userMessage = createUserMessage(text);
    const assistantMessage = buildMockAssistantReply(selectedItem, text);

    setMessages((currentMessages) => [...currentMessages, userMessage, assistantMessage]);
    setInput('');
  }

  function handleSave() {
    saveItem(selectedItem.id);
    submitPrompt('I saved this signal. What is the next safest action?');
  }

  function handleSnooze() {
    snoozeItem(selectedItem.id);
    submitPrompt('I snoozed this signal. What should I check when it returns?');
  }

  function handleResolve() {
    resolveItem(selectedItem.id);
    submitPrompt('I resolved this signal. Summarize what was closed.');
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.card}>
        <Text style={styles.source}>{selectedItem.sourceLabel}</Text>
        <Text style={styles.title}>{selectedItem.title}</Text>
        <Text style={[styles.priority, { color: priorityColor(selectedItem.priority) }]}> 
          {priorityLabel(selectedItem.priority)} · confidence {Math.round(selectedItem.confidence * 100)}%
        </Text>

        <Text style={styles.sectionTitle}>What it is</Text>
        <Text style={styles.body}>{selectedItem.summary}</Text>

        <Text style={styles.sectionTitle}>Why it matters</Text>
        <Text style={styles.body}>{selectedItem.whyImportant}</Text>

        <View style={styles.fieldGrid}>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldLabel}>Category</Text>
            <Text style={styles.fieldValue}>{selectedItem.category}</Text>
          </View>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldLabel}>State</Text>
            <Text style={styles.fieldValue}>{selectedItem.state}</Text>
          </View>
          {selectedItem.dueDate ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Due date</Text>
              <Text style={styles.fieldValue}>{selectedItem.dueDate}</Text>
            </View>
          ) : null}
          {selectedItem.amount ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Amount</Text>
              <Text style={styles.fieldValue}>{selectedItem.amount}</Text>
            </View>
          ) : null}
          {selectedItem.savedAt ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Saved</Text>
              <Text style={styles.fieldValue}>{selectedItem.savedAt.slice(0, 10)}</Text>
            </View>
          ) : null}
          {selectedItem.snoozedUntil ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Snoozed until</Text>
              <Text style={styles.fieldValue}>{selectedItem.snoozedUntil.slice(0, 10)}</Text>
            </View>
          ) : null}
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitleNoTop}>Recommended actions</Text>
        <View style={styles.actionsRow}>
          {selectedItem.actions.map((action) => (
            <Text key={action} style={styles.actionPill}>{actionLabel(action)}</Text>
          ))}
        </View>

        <View style={styles.primaryActionsRow}>
          <Pressable style={styles.primaryActionButton} onPress={handleSave}>
            <Text style={styles.primaryActionText}>Save</Text>
          </Pressable>
          <Pressable style={styles.secondaryActionButton} onPress={handleSnooze}>
            <Text style={styles.secondaryActionText}>Snooze</Text>
          </Pressable>
          <Pressable style={styles.resolveButton} onPress={handleResolve}>
            <Text style={styles.resolveText}>Resolve</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.chatCard}>
        <Text style={styles.sectionTitleNoTop}>Context AI chat</Text>
        <Text style={styles.chatHint}>Mock-only now. Later this calls POST /item-chat with item context.</Text>

        <View style={styles.messagesList}>
          {messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageBubble,
                message.role === 'user' ? styles.userBubble : styles.assistantBubble,
              ]}
            >
              <Text style={message.role === 'user' ? styles.userText : styles.assistantText}>{message.content}</Text>
            </View>
          ))}
        </View>

        <View style={styles.promptRow}>
          {quickPrompts.map((prompt) => (
            <Pressable key={prompt} style={styles.promptButton} onPress={() => submitPrompt(prompt)}>
              <Text style={styles.promptText}>{prompt}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.inputRow}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Ask about this signal..."
            placeholderTextColor={colors.muted}
            style={styles.input}
          />
          <Pressable style={styles.sendButton} onPress={() => submitPrompt(input)}>
            <Text style={styles.sendButtonText}>Send</Text>
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  notFoundContainer: { backgroundColor: colors.background, flex: 1, justifyContent: 'center', padding: 24 },
  content: { gap: 14, padding: 18, paddingBottom: 36 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 20, borderWidth: 1, padding: 18 },
  chatCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 20, borderWidth: 1, padding: 18 },
  source: { color: colors.muted, fontSize: 13, fontWeight: '800' },
  title: { color: colors.text, fontSize: 26, fontWeight: '900', lineHeight: 31, marginTop: 8 },
  priority: { fontSize: 14, fontWeight: '900', marginTop: 10 },
  sectionTitle: { color: colors.text, fontSize: 17, fontWeight: '900', marginTop: 16 },
  sectionTitleNoTop: { color: colors.text, fontSize: 17, fontWeight: '900' },
  body: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 7 },
  fieldGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 18 },
  fieldBox: { backgroundColor: colors.background, borderRadius: 14, minWidth: '46%', padding: 12 },
  fieldLabel: { color: colors.muted, fontSize: 12, fontWeight: '700' },
  fieldValue: { color: colors.text, fontSize: 15, fontWeight: '900', marginTop: 4, textTransform: 'capitalize' },
  actionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  actionPill: { backgroundColor: colors.background, borderRadius: 999, color: colors.text, fontSize: 13, fontWeight: '800', paddingHorizontal: 11, paddingVertical: 7 },
  primaryActionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 },
  primaryActionButton: { backgroundColor: colors.primary, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11 },
  primaryActionText: { color: '#FFFFFF', fontSize: 13, fontWeight: '900' },
  secondaryActionButton: { backgroundColor: colors.background, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11 },
  secondaryActionText: { color: colors.text, fontSize: 13, fontWeight: '900' },
  resolveButton: { backgroundColor: colors.text, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11 },
  resolveText: { color: '#FFFFFF', fontSize: 13, fontWeight: '900' },
  chatHint: { color: colors.muted, fontSize: 14, lineHeight: 20, marginTop: 7 },
  messagesList: { gap: 8, marginTop: 14 },
  messageBubble: { borderRadius: 16, padding: 12 },
  assistantBubble: { alignSelf: 'flex-start', backgroundColor: colors.background, maxWidth: '92%' },
  userBubble: { alignSelf: 'flex-end', backgroundColor: colors.primary, maxWidth: '92%' },
  assistantText: { color: colors.text, fontSize: 14, lineHeight: 20 },
  userText: { color: '#FFFFFF', fontSize: 14, lineHeight: 20 },
  promptRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  promptButton: { borderColor: colors.border, borderRadius: 999, borderWidth: 1, paddingHorizontal: 11, paddingVertical: 7 },
  promptText: { color: colors.primary, fontSize: 13, fontWeight: '800' },
  inputRow: { flexDirection: 'row', gap: 8, marginTop: 14 },
  input: { borderColor: colors.border, borderRadius: 16, borderWidth: 1, color: colors.text, flex: 1, fontSize: 15, padding: 14 },
  sendButton: { alignItems: 'center', backgroundColor: colors.primary, borderRadius: 16, justifyContent: 'center', paddingHorizontal: 16 },
  sendButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '900' },
});

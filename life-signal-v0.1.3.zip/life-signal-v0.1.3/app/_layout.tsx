import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SignalProvider } from '../src/state/SignalStore';

export default function RootLayout() {
  return (
    <SignalProvider>
      <StatusBar style="dark" />
      <Stack>
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="item/[id]" options={{ title: 'Signal detail' }} />
      </Stack>
    </SignalProvider>
  );
}

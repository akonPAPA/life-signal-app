import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { getVaultItems } from '../../src/lib/signalSelectors';
import { useSignals } from '../../src/state/SignalStore';
import { colors } from '../../src/theme/colors';

export default function VaultScreen() {
  const { items } = useSignals();
  const vaultItems = getVaultItems(items);
  const explicitlySavedCount = vaultItems.filter((item) => item.savedAt).length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Vault</Text>
      <Text style={styles.title}>Saved context and documents</Text>
      <Text style={styles.subtitle}>This becomes structured storage for receipts, forms, school docs, confirmations, contracts, and IDs.</Text>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{vaultItems.length}</Text>
          <Text style={styles.statLabel}>vault candidates</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{explicitlySavedCount}</Text>
          <Text style={styles.statLabel}>saved now</Text>
        </View>
      </View>

      <View style={styles.list}>
        {vaultItems.map((item) => (
          <View key={item.id} style={styles.row}>
            <Text style={styles.rowTitle}>{item.title}</Text>
            <Text style={styles.rowMeta}>{item.category} · {item.sourceLabel}</Text>
            <Text style={styles.rowWhy}>{item.whyImportant}</Text>
            {item.savedAt ? <Text style={styles.savedLabel}>Saved · {item.savedAt.slice(0, 10)}</Text> : null}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 18 },
  statCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 18, borderWidth: 1, flex: 1, padding: 14 },
  statValue: { color: colors.text, fontSize: 24, fontWeight: '900' },
  statLabel: { color: colors.muted, fontSize: 12, fontWeight: '700', marginTop: 4 },
  list: { marginTop: 20, gap: 10 },
  row: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 16, borderWidth: 1, padding: 16 },
  rowTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  rowMeta: { color: colors.muted, fontSize: 13, fontWeight: '600', marginTop: 6, textTransform: 'capitalize' },
  rowWhy: { color: colors.muted, fontSize: 14, lineHeight: 20, marginTop: 8 },
  savedLabel: { color: colors.primary, fontSize: 12, fontWeight: '900', marginTop: 10 },
});

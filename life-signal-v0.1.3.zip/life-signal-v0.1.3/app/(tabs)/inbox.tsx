import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SignalCard } from '../../src/components/SignalCard';
import { useSignals } from '../../src/state/SignalStore';
import { colors } from '../../src/theme/colors';

export default function InboxScreen() {
  const { items } = useSignals();
  const unresolvedItems = items.filter((item) => item.state !== 'resolved');

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Unified inbox</Text>
      <Text style={styles.title}>Signals that may need attention</Text>
      <Text style={styles.subtitle}>Local mock state now. Real Gmail/Outlook/import pipeline later.</Text>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{unresolvedItems.length}</Text>
          <Text style={styles.statLabel}>active</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{items.filter((item) => item.state === 'resolved').length}</Text>
          <Text style={styles.statLabel}>resolved</Text>
        </View>
      </View>

      <View style={styles.list}>
        {unresolvedItems.map((item) => (
          <SignalCard key={item.id} item={item} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 18 },
  statCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 18, borderWidth: 1, flex: 1, padding: 14 },
  statValue: { color: colors.text, fontSize: 24, fontWeight: '900' },
  statLabel: { color: colors.muted, fontSize: 12, fontWeight: '700', marginTop: 4 },
  list: { marginTop: 20 },
});

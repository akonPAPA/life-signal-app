import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SignalCard } from '../../src/components/SignalCard';
import { getOpenActionItems, getResolvedItems } from '../../src/lib/signalSelectors';
import { useSignals } from '../../src/state/SignalStore';
import { colors } from '../../src/theme/colors';

export default function ActionsScreen() {
  const { items } = useSignals();
  const actionItems = getOpenActionItems(items);
  const resolvedItems = getResolvedItems(items);
  const urgentCount = actionItems.filter((item) => item.priority === 'urgent').length;
  const withDeadlineCount = actionItems.filter((item) => item.dueDate).length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Actions</Text>
      <Text style={styles.title}>Open next steps</Text>
      <Text style={styles.subtitle}>
        This screen is not a generic task list. It shows only signals that can be converted into a concrete action.
      </Text>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{actionItems.length}</Text>
          <Text style={styles.statLabel}>open actions</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{urgentCount}</Text>
          <Text style={styles.statLabel}>urgent</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{withDeadlineCount}</Text>
          <Text style={styles.statLabel}>dated</Text>
        </View>
      </View>

      <View style={styles.list}>
        {actionItems.map((item) => (
          <SignalCard key={item.id} item={item} />
        ))}
      </View>

      {resolvedItems.length > 0 ? (
        <View style={styles.resolvedSection}>
          <Text style={styles.resolvedTitle}>Resolved</Text>
          {resolvedItems.map((item) => (
            <View key={item.id} style={styles.resolvedRow}>
              <Text style={styles.resolvedRowTitle}>{item.title}</Text>
              <Text style={styles.resolvedRowMeta}>Closed · {item.resolvedAt ? item.resolvedAt.slice(0, 10) : 'now'}</Text>
            </View>
          ))}
        </View>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 18 },
  statCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 18, borderWidth: 1, flex: 1, padding: 14 },
  statValue: { color: colors.text, fontSize: 24, fontWeight: '900' },
  statLabel: { color: colors.muted, fontSize: 12, fontWeight: '700', marginTop: 4 },
  list: { marginTop: 20 },
  resolvedSection: { marginTop: 20 },
  resolvedTitle: { color: colors.text, fontSize: 17, fontWeight: '900', marginBottom: 10 },
  resolvedRow: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 16, borderWidth: 1, marginBottom: 10, padding: 14 },
  resolvedRowTitle: { color: colors.text, fontSize: 15, fontWeight: '800' },
  resolvedRowMeta: { color: colors.muted, fontSize: 12, fontWeight: '700', marginTop: 5 },
});

import { SignalActionType, SignalItem, SignalPriority } from '../types/domain';

const priorityWeight: Record<SignalPriority, number> = {
  urgent: 4,
  high: 3,
  medium: 2,
  low: 1,
};

export function compareSignalsByPriority(a: SignalItem, b: SignalItem): number {
  const priorityDiff = priorityWeight[b.priority] - priorityWeight[a.priority];

  if (priorityDiff !== 0) {
    return priorityDiff;
  }

  if (a.dueDate && b.dueDate) {
    return a.dueDate.localeCompare(b.dueDate);
  }

  if (a.dueDate) {
    return -1;
  }

  if (b.dueDate) {
    return 1;
  }

  return b.createdAt.localeCompare(a.createdAt);
}

export function getRadarItems(items: SignalItem[]): SignalItem[] {
  return items
    .filter((item) => item.state !== 'resolved')
    .filter((item) => item.priority === 'urgent' || item.priority === 'high' || Boolean(item.dueDate))
    .sort(compareSignalsByPriority);
}

export function getVaultItems(items: SignalItem[]): SignalItem[] {
  return items
    .filter((item) => Boolean(item.savedAt) || item.actions.includes('save') || item.category === 'docs')
    .sort(compareSignalsByPriority);
}

export function getOpenActionItems(items: SignalItem[]): SignalItem[] {
  return items
    .filter((item) => item.state !== 'resolved')
    .filter((item) => item.actions.some((action) => action !== 'explain'))
    .sort(compareSignalsByPriority);
}

export function getResolvedItems(items: SignalItem[]): SignalItem[] {
  return items
    .filter((item) => item.state === 'resolved')
    .sort((a, b) => (b.resolvedAt ?? b.createdAt).localeCompare(a.resolvedAt ?? a.createdAt));
}

export function actionLabel(action: SignalActionType): string {
  switch (action) {
    case 'remind':
      return 'Remind';
    case 'calendar':
      return 'Calendar';
    case 'save':
      return 'Save';
    case 'draft_reply':
      return 'Draft reply';
    case 'explain':
      return 'Explain';
    case 'resolve':
      return 'Resolve';
    case 'snooze':
      return 'Snooze';
  }
}

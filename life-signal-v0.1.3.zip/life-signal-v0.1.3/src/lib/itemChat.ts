import { SignalItem } from '../types/domain';

export type ChatRole = 'assistant' | 'user';

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  createdAt: string;
}

export const quickPrompts = [
  'Explain simply',
  'What should I do?',
  'Draft reply',
] as const;

function nowIso(): string {
  return new Date().toISOString();
}

function createMessage(role: ChatRole, content: string): ChatMessage {
  return {
    id: `${role}-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    role,
    content,
    createdAt: nowIso(),
  };
}

export function createUserMessage(content: string): ChatMessage {
  return createMessage('user', content.trim());
}

export function createInitialAssistantMessage(item: SignalItem): ChatMessage {
  return createMessage(
    'assistant',
    `I am scoped to this signal only: ${item.title}. I can explain it, extract what matters, suggest next actions, or draft a short reply.`
  );
}

export function buildMockAssistantReply(item: SignalItem, userPrompt: string): ChatMessage {
  const prompt = userPrompt.toLowerCase();

  if (prompt.includes('what should') || prompt.includes('do') || prompt.includes('что делать')) {
    return createMessage(
      'assistant',
      `Recommended next step: ${item.actions.join(', ')}. Reason: ${item.whyImportant}${item.dueDate ? ` Deadline: ${item.dueDate}.` : ''}`
    );
  }

  if (prompt.includes('draft') || prompt.includes('reply') || prompt.includes('ответ')) {
    return createMessage(
      'assistant',
      `Draft: Hi, thanks for the update. I have reviewed this and will take the required action. Please let me know if anything else is needed from my side.`
    );
  }

  if (prompt.includes('deadline') || prompt.includes('date') || prompt.includes('дедлайн')) {
    return createMessage(
      'assistant',
      item.dueDate
        ? `Detected deadline: ${item.dueDate}. Confidence: ${Math.round(item.confidence * 100)}%.`
        : `I do not see a confirmed deadline in this mock signal. Confidence: ${Math.round(item.confidence * 100)}%.`
    );
  }

  return createMessage(
    'assistant',
    `${item.summary} Why it matters: ${item.whyImportant} Priority: ${item.priority}. Confidence: ${Math.round(item.confidence * 100)}%.`
  );
}

import { Link, type Href } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { priorityColor, priorityLabel } from '../lib/priority';
import { actionLabel } from '../lib/signalSelectors';
import { colors } from '../theme/colors';
import { SignalItem } from '../types/domain';

interface SignalCardProps {
  item: SignalItem;
}

export function SignalCard({ item }: SignalCardProps) {
  const detailHref = `/item/${encodeURIComponent(item.id)}` as Href;

  return (
    <Link href={detailHref} asChild>
      <Pressable style={styles.card}>
        <View style={styles.headerRow}>
          <Text style={styles.source}>{item.sourceLabel}</Text>
          <Text style={[styles.priority, { color: priorityColor(item.priority) }]}>
            {priorityLabel(item.priority)}
          </Text>
        </View>

        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.summary}>{item.summary}</Text>

        <View style={styles.metaRow}>
          <Text style={styles.meta}>Category: {item.category}</Text>
          <Text style={styles.meta}>State: {item.state}</Text>
          {item.dueDate ? <Text style={styles.meta}>Due: {item.dueDate}</Text> : null}
          {item.amount ? <Text style={styles.meta}>{item.amount}</Text> : null}
        </View>

        <View style={styles.actionsRow}>
          {item.actions.slice(0, 3).map((action) => (
            <Text key={action} style={styles.actionPill}>{actionLabel(action)}</Text>
          ))}
        </View>
      </Pressable>
    </Link>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: 18,
    borderWidth: 1,
    gap: 8,
    marginBottom: 12,
    padding: 16,
  },
  headerRow: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  source: {
    color: colors.muted,
    fontSize: 13,
    fontWeight: '600',
  },
  priority: {
    fontSize: 13,
    fontWeight: '800',
  },
  title: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '800',
  },
  summary: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 20,
  },
  metaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  meta: {
    backgroundColor: colors.background,
    borderRadius: 999,
    color: colors.muted,
    fontSize: 12,
    fontWeight: '700',
    paddingHorizontal: 10,
    paddingVertical: 5,
    textTransform: 'capitalize',
  },
  actionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  actionPill: {
    borderColor: colors.border,
    borderRadius: 999,
    borderWidth: 1,
    color: colors.text,
    fontSize: 12,
    fontWeight: '800',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
});

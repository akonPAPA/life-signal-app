import { createContext, ReactNode, useContext, useMemo, useState } from 'react';
import { mockItems } from '../data/mockItems';
import { SignalItem } from '../types/domain';

interface SignalStoreValue {
  items: SignalItem[];
  getItemById: (id: string) => SignalItem | undefined;
  saveItem: (id: string) => void;
  resolveItem: (id: string) => void;
  snoozeItem: (id: string) => void;
  resetItems: () => void;
}

const SignalStoreContext = createContext<SignalStoreValue | null>(null);

function nowIso(): string {
  return new Date().toISOString();
}

function sevenDaysFromNowIso(): string {
  const date = new Date();
  date.setDate(date.getDate() + 7);
  return date.toISOString();
}

export function SignalProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<SignalItem[]>(mockItems);

  const value = useMemo<SignalStoreValue>(() => {
    function updateItem(id: string, updater: (item: SignalItem) => SignalItem) {
      setItems((currentItems) => currentItems.map((item) => (item.id === id ? updater(item) : item)));
    }

    return {
      items,
      getItemById: (id: string) => items.find((item) => item.id === id),
      saveItem: (id: string) => {
        updateItem(id, (item) => ({ ...item, savedAt: item.savedAt ?? nowIso(), state: item.state === 'new' ? 'reviewed' : item.state }));
      },
      resolveItem: (id: string) => {
        updateItem(id, (item) => ({ ...item, state: 'resolved', resolvedAt: nowIso() }));
      },
      snoozeItem: (id: string) => {
        updateItem(id, (item) => ({ ...item, state: 'snoozed', snoozedUntil: sevenDaysFromNowIso() }));
      },
      resetItems: () => setItems(mockItems),
    };
  }, [items]);

  return <SignalStoreContext.Provider value={value}>{children}</SignalStoreContext.Provider>;
}

export function useSignals(): SignalStoreValue {
  const value = useContext(SignalStoreContext);

  if (!value) {
    throw new Error('useSignals must be used inside SignalProvider');
  }

  return value;
}

import { Link } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../src/theme/colors';

export default function OnboardingScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>Life Signal</Text>
      <Text style={styles.title}>Turn scattered life signals into clear next actions.</Text>
      <Text style={styles.subtitle}>
        v0.1 starts with mock inbox, radar, vault, and contextual AI chat per item.
      </Text>

      <Link href="/(tabs)/inbox" style={styles.button}>
        Open app shell
      </Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background,
    flex: 1,
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    color: colors.primary,
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 16,
  },
  title: {
    color: colors.text,
    fontSize: 34,
    fontWeight: '900',
    letterSpacing: -1,
    lineHeight: 39,
  },
  subtitle: {
    color: colors.muted,
    fontSize: 16,
    lineHeight: 23,
    marginTop: 14,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 16,
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    marginTop: 28,
    overflow: 'hidden',
    paddingHorizontal: 18,
    paddingVertical: 15,
    textAlign: 'center',
  },
});

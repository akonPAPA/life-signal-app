import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SignalCard } from '../../src/components/SignalCard';
import { mockItems } from '../../src/data/mockItems';
import { colors } from '../../src/theme/colors';

export default function RadarScreen() {
  const priorityItems = mockItems.filter((item) => item.priority === 'urgent' || item.priority === 'high');

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Radar</Text>
      <Text style={styles.title}>High-risk and upcoming</Text>
      <Text style={styles.subtitle}>Only things with deadline, risk, money, reply-needed, or document expiry should land here.</Text>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{priorityItems.length}</Text>
          <Text style={styles.statLabel}>priority signals</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{mockItems.filter((item) => item.dueDate).length}</Text>
          <Text style={styles.statLabel}>with deadlines</Text>
        </View>
      </View>

      <View style={styles.list}>
        {priorityItems.map((item) => (
          <SignalCard key={item.id} item={item} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  statsRow: { flexDirection: 'row', gap: 12, marginTop: 18 },
  statCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 18, borderWidth: 1, flex: 1, padding: 16 },
  statValue: { color: colors.text, fontSize: 28, fontWeight: '900' },
  statLabel: { color: colors.muted, fontSize: 13, fontWeight: '700', marginTop: 4 },
  list: { marginTop: 20 },
});

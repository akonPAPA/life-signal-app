import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SignalCard } from '../../src/components/SignalCard';
import { mockItems } from '../../src/data/mockItems';
import { colors } from '../../src/theme/colors';

export default function InboxScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Unified inbox</Text>
      <Text style={styles.title}>Signals that may need attention</Text>
      <Text style={styles.subtitle}>Mock data now. Real Gmail/Outlook/import pipeline later.</Text>

      <View style={styles.list}>
        {mockItems.map((item) => (
          <SignalCard key={item.id} item={item} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  list: { marginTop: 20 },
});

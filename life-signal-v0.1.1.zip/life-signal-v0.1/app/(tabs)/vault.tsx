import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { mockItems } from '../../src/data/mockItems';
import { colors } from '../../src/theme/colors';

export default function VaultScreen() {
  const vaultItems = mockItems.filter((item) => item.actions.includes('save'));

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>Vault</Text>
      <Text style={styles.title}>Saved context and documents</Text>
      <Text style={styles.subtitle}>This becomes structured storage for receipts, forms, school docs, confirmations, contracts, and IDs.</Text>

      <View style={styles.list}>
        {vaultItems.map((item) => (
          <View key={item.id} style={styles.row}>
            <Text style={styles.rowTitle}>{item.title}</Text>
            <Text style={styles.rowMeta}>{item.category} · {item.sourceLabel}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { padding: 18, paddingBottom: 36 },
  kicker: { color: colors.primary, fontSize: 13, fontWeight: '900', textTransform: 'uppercase' },
  title: { color: colors.text, fontSize: 28, fontWeight: '900', marginTop: 6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 8 },
  list: { marginTop: 20, gap: 10 },
  row: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 16, borderWidth: 1, padding: 16 },
  rowTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  rowMeta: { color: colors.muted, fontSize: 13, fontWeight: '600', marginTop: 6, textTransform: 'capitalize' },
});

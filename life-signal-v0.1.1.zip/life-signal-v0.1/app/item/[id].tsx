import { useLocalSearchParams } from 'expo-router';
import { ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { mockItems } from '../../src/data/mockItems';
import { priorityColor, priorityLabel } from '../../src/lib/priority';
import { colors } from '../../src/theme/colors';

export default function ItemDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const item = mockItems.find((entry) => entry.id === id) ?? mockItems[0];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.card}>
        <Text style={styles.source}>{item.sourceLabel}</Text>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={[styles.priority, { color: priorityColor(item.priority) }]}>
          {priorityLabel(item.priority)} · confidence {Math.round(item.confidence * 100)}%
        </Text>

        <Text style={styles.sectionTitle}>What it is</Text>
        <Text style={styles.body}>{item.summary}</Text>

        <Text style={styles.sectionTitle}>Why it matters</Text>
        <Text style={styles.body}>{item.whyImportant}</Text>

        <View style={styles.fieldGrid}>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldLabel}>Category</Text>
            <Text style={styles.fieldValue}>{item.category}</Text>
          </View>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldLabel}>State</Text>
            <Text style={styles.fieldValue}>{item.state}</Text>
          </View>
          {item.dueDate ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Due date</Text>
              <Text style={styles.fieldValue}>{item.dueDate}</Text>
            </View>
          ) : null}
          {item.amount ? (
            <View style={styles.fieldBox}>
              <Text style={styles.fieldLabel}>Amount</Text>
              <Text style={styles.fieldValue}>{item.amount}</Text>
            </View>
          ) : null}
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Recommended actions</Text>
        <View style={styles.actionsRow}>
          {item.actions.map((action) => (
            <Text key={action} style={styles.actionPill}>{action.replace('_', ' ')}</Text>
          ))}
        </View>
      </View>

      <View style={styles.chatCard}>
        <Text style={styles.sectionTitle}>Context AI chat</Text>
        <Text style={styles.aiMessage}>
          Ask about this item only. Later this panel will call POST /item-chat with the item context.
        </Text>
        <View style={styles.promptRow}>
          <Text style={styles.prompt}>Explain simply</Text>
          <Text style={styles.prompt}>What should I do?</Text>
          <Text style={styles.prompt}>Draft reply</Text>
        </View>
        <TextInput
          placeholder="Ask about this signal..."
          placeholderTextColor={colors.muted}
          style={styles.input}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: colors.background, flex: 1 },
  content: { gap: 14, padding: 18, paddingBottom: 36 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 20, borderWidth: 1, padding: 18 },
  chatCard: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 20, borderWidth: 1, padding: 18 },
  source: { color: colors.muted, fontSize: 13, fontWeight: '800' },
  title: { color: colors.text, fontSize: 26, fontWeight: '900', lineHeight: 31, marginTop: 8 },
  priority: { fontSize: 14, fontWeight: '900', marginTop: 10 },
  sectionTitle: { color: colors.text, fontSize: 17, fontWeight: '900', marginTop: 16 },
  body: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 7 },
  fieldGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 18 },
  fieldBox: { backgroundColor: colors.background, borderRadius: 14, minWidth: '46%', padding: 12 },
  fieldLabel: { color: colors.muted, fontSize: 12, fontWeight: '700' },
  fieldValue: { color: colors.text, fontSize: 15, fontWeight: '900', marginTop: 4, textTransform: 'capitalize' },
  actionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  actionPill: { backgroundColor: colors.background, borderRadius: 999, color: colors.text, fontSize: 13, fontWeight: '800', paddingHorizontal: 11, paddingVertical: 7, textTransform: 'capitalize' },
  aiMessage: { backgroundColor: colors.background, borderRadius: 16, color: colors.text, fontSize: 14, lineHeight: 20, marginTop: 10, padding: 12 },
  promptRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  prompt: { borderColor: colors.border, borderRadius: 999, borderWidth: 1, color: colors.primary, fontSize: 13, fontWeight: '800', paddingHorizontal: 11, paddingVertical: 7 },
  input: { borderColor: colors.border, borderRadius: 16, borderWidth: 1, color: colors.text, fontSize: 15, marginTop: 14, padding: 14 },
});

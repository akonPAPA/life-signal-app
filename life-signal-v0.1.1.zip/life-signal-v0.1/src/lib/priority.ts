import { SignalPriority } from '../types/domain';
import { colors } from '../theme/colors';

export function priorityLabel(priority: SignalPriority): string {
  switch (priority) {
    case 'urgent':
      return 'Urgent';
    case 'high':
      return 'High';
    case 'medium':
      return 'Medium';
    case 'low':
      return 'Low';
  }
}

export function priorityColor(priority: SignalPriority): string {
  switch (priority) {
    case 'urgent':
      return colors.urgent;
    case 'high':
      return colors.high;
    case 'medium':
      return colors.medium;
    case 'low':
      return colors.low;
  }
}

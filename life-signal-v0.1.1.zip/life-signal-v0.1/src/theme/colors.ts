export const colors = {
  background: '#F6F7F9',
  surface: '#FFFFFF',
  text: '#101318',
  muted: '#69707D',
  border: '#E2E6EA',
  primary: '#1F5EFF',
  urgent: '#B42318',
  high: '#B54708',
  medium: '#175CD3',
  low: '#475467',
};

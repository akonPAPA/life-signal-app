export type SignalCategory =
  | 'study'
  | 'money'
  | 'docs'
  | 'admin'
  | 'email'
  | 'subscription';

export type SignalPriority = 'urgent' | 'high' | 'medium' | 'low';

export type ResolutionState = 'new' | 'reviewed' | 'acted' | 'resolved' | 'snoozed';

export type SignalActionType =
  | 'remind'
  | 'calendar'
  | 'save'
  | 'draft_reply'
  | 'explain'
  | 'resolve';

export type SourceType = 'gmail' | 'outlook' | 'pdf' | 'screenshot' | 'manual';

export interface SignalItem {
  id: string;
  title: string;
  sourceType: SourceType;
  sourceLabel: string;
  category: SignalCategory;
  priority: SignalPriority;
  state: ResolutionState;
  summary: string;
  whyImportant: string;
  dueDate?: string;
  amount?: string;
  confidence: number;
  actions: SignalActionType[];
  createdAt: string;
}
